function tambah(a, b) {
  //function biasa
  return a + b;
}

console.log(tambah(1, 2));

const tambahArrow = (a, b) => a + b; // arrow function
console.log(tambahArrow(2, 3));