// import { tambah, kurang } from "./utils.js";

// console.log(tambah(5, 3));
// console.log(kurang(5, 3));

import { Counter } from "./counterComponent.js";

Counter();