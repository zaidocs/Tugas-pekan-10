// const app = document.getElementById("app");
// app.innerHTML = `
//   <button id="btnKlik">Klik Saya</button>
// `;
// const button = document.getElementById("btnKlik");
// button.addEventListener("click", function () {
//   alert("Tombol berhasil diklik");
// });

// const app = document.getElementById("app");

// app.innerHTML = `
//   <button id="btnKlik">Klik Saya</button>
// `;

// const button = document.getElementById("btnKlik");

// function handleClick() {
//   alert("Function handleClick dipanggil");
// }

// button.addEventListener("click", handleClick);

// const app = document.getElementById("app");

// app.innerHTML = `
//   <button id="btnKlik">Klik Saya</button>
// `;

// const button = document.getElementById("btnKlik");

// button.addEventListener("click", function () {
//   console.log(this);
//   this.innerText = "Sudah Diklik";
// });

const app = document.getElementById("app");

app.innerHTML = `
  <button id="btnKlik">Klik Saya</button>
`;

const button = document.getElementById("btnKlik");

button.addEventListener("click", () => {
  console.log(this);
});