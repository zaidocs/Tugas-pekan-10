const products = ["Laptop", "Mouse", "Keyboard"];
const app = document.getElementById("app");
const products = ["Laptop", "Mouse", "Keyboard"];
const app = document.getElementById("app");

app.innerHTML = `
  <ul>
    <li>${products[0]}</li>
    <li>${products[1]}</li>
    <li>${products[2]}</li>
  </ul>
`;
const products = [
  { name: "Laptop", price: 10000000 },
  { name: "Mouse", price: 150000 },
  { name: "Keyboard", price: 300000 }
];
const app = document.getElementById("app");
const app = document.getElementById("app");

const listHTML = products
  .map(item => `
    <div>
      <h4>${item.name}</h4>
      <p>Harga: ${item.price}</p>
    </div>
  `)
  .join("");

app.innerHTML = listHTML;