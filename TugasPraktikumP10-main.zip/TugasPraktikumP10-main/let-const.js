// let counter = 1;
// counter = 2; // diperbolehkan
// console.log(counter);

// const MAX = 10;
// MAX = 20; // error

if (true) {
  let angka = 5;
  console.log(angka); // bisa diakses
}
console.log(angka); // error