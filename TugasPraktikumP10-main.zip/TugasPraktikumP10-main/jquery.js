$("#judul").css("color", "blue");

$("#judul").text("jQuery Berhasil Jalan");

$("#btn").click(function () {
  alert("Tombol diklik!");
});

$("#btn").click(function () {
  $("#judul").text("Judul Berubah karena Klik");
  $("#judul").css("color", "red");
});