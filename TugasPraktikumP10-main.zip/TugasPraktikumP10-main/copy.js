const user = {
  name: "Vanes",
  address: {
    city: "Bandung",
  },
};

const userCopy = { ...user };

userCopy.name = "Karin";
userCopy.address.city = "Jakarta";

console.log("User Asli:", user);
console.log("User Copy:", userCopy);

const numbers = [{ value: 1 }, { value: 2 }];

const numbersCopy = [...numbers];

numbersCopy[0].value = 99;

console.log("Array Asli:", numbers);
console.log("Array Copy:", numbersCopy);

const userDeep = JSON.parse(JSON.stringify(user));

userDeep.address.city = "Surabaya";

console.log("User Asli:", user);
console.log("User Deep Copy:", userDeep);